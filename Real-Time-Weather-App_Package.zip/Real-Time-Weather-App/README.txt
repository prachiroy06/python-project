Real-Time Weather App - Instructions

1. Obtain a free API key from https://openweathermap.org/api
2. Open the file script.js and replace YOUR_API_KEY with your actual API key.
3. Open index.html in a browser (double-click the file or serve via a local server).
4. Enter a city name and press 'Get Weather' or Enter.
