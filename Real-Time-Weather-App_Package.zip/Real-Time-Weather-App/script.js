// Real-Time Weather App using Fetch (AJAX) and OpenWeatherMap API
// Replace 'YOUR_API_KEY' with your OpenWeatherMap API key
const apiKey = "YOUR_API_KEY"; // <-- ENTER YOUR API KEY HERE

document.getElementById('getWeather').addEventListener('click', getWeather);
document.getElementById('city').addEventListener('keydown', function(e){ if(e.key==='Enter') getWeather(); });

function showLoading(show){
  const el = document.getElementById('loading');
  if(show) el.classList.remove('hidden'); else el.classList.add('hidden');
}

function getWeather(){
  const city = document.getElementById('city').value.trim();
  const weatherDiv = document.getElementById('weather');
  if(!city){
    weatherDiv.innerHTML = '<p style="color:crimson;">Please enter a city name.</p>';
    return;
  }
  showLoading(true);
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric`;

  fetch(url)
    .then(response => {
      showLoading(false);
      if(!response.ok) throw new Error('City not found or API error');
      return response.json();
    })
    .then(data => {
      weatherDiv.innerHTML = `
        <h2>${data.name}, ${data.sys.country}</h2>
        <h3>${Math.round(data.main.temp)}°C</h3>
        <p style="text-transform:capitalize;">${data.weather[0].description}</p>
        <p>Humidity: ${data.main.humidity}%</p>
        <p>Wind Speed: ${data.wind.speed} m/s</p>
      `;
    })
    .catch(err => {
      showLoading(false);
      weatherDiv.innerHTML = '<p style="color:crimson;">' + err.message + '</p>';
    });
}
